/*
 ============================================================================
 Name        : Elf_Dwarf_Decoder.c
 Author      : Vasiliu Vlad
 Version     :
 Copyright   : Copyright 2014
 Description :  DWARF Reader
 ============================================================================
 */

#include <sys/types.h> /* For open() */
#include <sys/stat.h> /* For open() */
#include <fcntl.h> /* For open() */
#include <stdlib.h> /* For exit() */
#include <unistd.h> /* For close() */
#include <stdio.h>
#include <errno.h>
#include "dwarf.h"
#include "libdwarf.h"
#include "die_func.h"


static void read_cu_list(Dwarf_Debug dbg);
static void get_die_and_siblings(Dwarf_Debug dbg, Dwarf_Die in_die);

int
main(int argc, char **argv)
{
	/* ---- Opaque Data for the DWARF engine ----*/
    Dwarf_Debug dbg = 0;
    /* ---- File Descriptor in ----*/
    int fd    = -1;
    /* ---- File name ----*/
    const char *filepath = NULL;

    int res = DW_DLV_ERROR;

    Dwarf_Error error;
    Dwarf_Handler errhand = 0;
    Dwarf_Ptr errarg = 0;

    if(argc < 2)
    {
        printf("ERROR : Parameters Not found !\n");
        exit(1);

    }
    else
    {
    	/* ---- Open Elf file ----*/
        filepath = argv[1];
    }

    fd = open(filepath,O_RDONLY);
    /* ----- Check for the correct opening ----- */
    if(fd < 0)
    {
        printf("ERROR : Failure in opening  %s\n",filepath);
        exit(1);
    }



    /* ---- Init the DWARF library --- */
    res = dwarf_init(fd,DW_DLC_READ,errhand,errarg, &dbg,&error);

    if(res != DW_DLV_OK)
    {
        printf("ERROR: Error in  DWARF processing\n");
        exit(1);
    }


    /* ---- Read all compile units list ---- */
    read_cu_list(dbg);


    /* ---- Close the DWARF processing ---- */
    res = dwarf_finish(dbg,&error);

    if(res != DW_DLV_OK)
    {
        printf("ERROR : dwarf_finish failed!\n");
    }

    /* ---- Close the File Descriptors ---- */
    close(fd);
    return 0;
}

static void read_cu_list(Dwarf_Debug dbg )
{
    Dwarf_Unsigned cu_header_length = 0;
    Dwarf_Half version_stamp = 0;
    Dwarf_Unsigned abbrev_offset = 0;
    Dwarf_Half address_size = 0;
    Dwarf_Unsigned next_cu_header = 0;
    Dwarf_Error error;
    int cu_number = 0;

    /* ---- For all Compiler units (*.c files ) do ----- */
    for(;;++cu_number)
    {
        Dwarf_Die no_die = 0;
        Dwarf_Die cu_die = 0;
        int res = DW_DLV_ERROR;

     /* ----- Read CU header ---- */
        res = dwarf_next_cu_header(dbg,&cu_header_length,
            &version_stamp, &abbrev_offset, &address_size,
            &next_cu_header, &error);

        if(res == DW_DLV_ERROR)
        {
            printf("ERROR : Error in dwarf_next_cu_header\n");
            exit(1);
        }

        if(res == DW_DLV_NO_ENTRY)
        {
            /* Done. */
            return;
        }

        /* The CU will have a single sibling, a cu_die. */
        res = dwarf_siblingof(dbg,no_die,&cu_die,&error);
        if(res == DW_DLV_ERROR)
        {
            printf("ERROR : Error in dwarf_siblingof on CU die \n");
            exit(1);
        }

        if(res == DW_DLV_NO_ENTRY)
        {
            /* Impossible case. */
            printf("no entry! in dwarf_siblingof on CU die \n");
            exit(1);
        }

        /* ----- Handle the Compiling units ----*/
        {
        	/* ---- Get the Child of a Compiling unit ---- */
        	Dwarf_Die child_cu_die = 0;

        	res = dwarf_child(cu_die,&child_cu_die,&error);

        	if(res == DW_DLV_ERROR)
        	{
        		printf("ERROR: Error in ELF reading  \n");
        		exit(1);
        	}
        	if(res == DW_DLV_NO_ENTRY)
        	{
        		/* Impossible case. */
        		//printf("INFO: No Entry in Compiling unit.  \n");
        	}
        	else
        	{
        		/* ---- Go an find local variables ---- */
        		get_die_and_siblings(dbg,child_cu_die);
        	}
        }

        dwarf_dealloc(dbg,cu_die,DW_DLA_DIE);
    }
}

static void get_die_and_siblings(Dwarf_Debug dbg, Dwarf_Die in_die)
{
    int res = DW_DLV_ERROR;
    Dwarf_Die cur_die = in_die;
    Dwarf_Die child = 0;
    Dwarf_Die child1 = 0;
    Dwarf_Error error;
    /* ---- For all the DIE's do ----*/
    for(;;)
    {
    	/* ---- Read the next DIE  ---- */;
        res = dwarf_siblingof(dbg,cur_die,&child,&error);

        if(res == DW_DLV_ERROR)
        {
            printf("ERROR : Error in reading the DIE's \n");
            exit(1);
        }

        if(res == DW_DLV_NO_ENTRY)
        {
            /* Done at this level. */
            break;
        }

        if(res == DW_DLV_OK)
        {
        	/* ---- Print the Variable DIE ---*/
        	child1 =child;
        	DIE_HandleVariable(dbg,child1);
        }


        if(cur_die != in_die)
        {
        /* ---- Dealoc DIE ---- */
        dwarf_dealloc(dbg,cur_die,DW_DLA_DIE);

        }

        cur_die = child;
    }

    return;
}



