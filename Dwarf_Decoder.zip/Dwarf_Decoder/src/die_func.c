#include <sys/types.h> /* For open() */
#include <sys/stat.h> /* For open() */
#include <fcntl.h> /* For open() */
#include <stdlib.h> /* For exit() */
#include <unistd.h> /* For close() */
#include <stdio.h>
#include <string.h>
#include <errno.h>
#include "dwarf.h"
#include "libdwarf.h"
#include "die_list.h"
#include "die_func.h"

#define DIE_VAR_NAME_SIZE (1024*8)
char DIE_VAR_NAME[DIE_VAR_NAME_SIZE];
unsigned int DIE_VAR_NAME_CNT = 0;

int  DIE_Get_DIE_Type(Dwarf_Debug dbg, Dwarf_Die die, Dwarf_Die *child);
Dwarf_Half DIE_GetDieRealType(Dwarf_Debug dbg, Dwarf_Die die, Dwarf_Die *child,unsigned long address);
int DIE_IsVariable(Dwarf_Debug dbg, Dwarf_Die die);
void DIE__AddMembers2Stack(Dwarf_Debug dbg, Dwarf_Die die,unsigned long address);
int DIE_GetDIEName(Dwarf_Debug dbg, Dwarf_Die print_me,char *var_name);
void DIE_GetStaticAddress(Dwarf_Debug dbg, Dwarf_Die print_me, Dwarf_Addr *Addr);
void DIE_GetMemberLocation(Dwarf_Debug dbg, Dwarf_Die die, Dwarf_Unsigned *off);
void DIE_GetMemberSize(Dwarf_Debug dbg, Dwarf_Die die, Dwarf_Unsigned *size);
int DIE_GetDIEBaseTypeName(Dwarf_Debug dbg, Dwarf_Die print_me,char *var_name);
int  DIE_Get_ArraySize(Dwarf_Debug dbg, Dwarf_Die die);

int DIE_GetDIEName(Dwarf_Debug dbg, Dwarf_Die print_me,char *var_name)
{
	char *name = 0;
	Dwarf_Error error = 0;

	/* ---- Get the Name of the DIE ----*/
	int res = dwarf_diename(print_me,&name,&error);

	if(res == DW_DLV_OK)
	{
		/* ---- Get the Name ---- */
		strcpy(var_name,name);
	}

	dwarf_dealloc(dbg,name,DW_DLA_STRING);

	return res;
}

int DIE_GetDIEBaseTypeName(Dwarf_Debug dbg, Dwarf_Die print_me,char *var_name)
{
	char *name = NULL;
	Dwarf_Error error = 0;
	Dwarf_Attribute Encoding;
	Dwarf_Unsigned  type;
	int res;

	/* ---- Get the Encoding of the DIE ----*/
	res = dwarf_attr(print_me,DW_AT_encoding,&Encoding,&error);

	if(res == DW_DLV_OK)
	{
		res =dwarf_formudata(Encoding,&type,&error);

		if(res == DW_DLV_OK)
		{
			/* ---- Get the Name ---- */
			res = dwarf_get_ATE_name(type,(const char **)(&name));

			if(res == DW_DLV_OK)
			{
				strcpy(var_name,name);
				dwarf_dealloc(dbg,name,DW_DLA_STRING);
			}
		}
	}


	dwarf_dealloc(dbg,name,DW_DLA_STRING);

	return res;
}

void DIE_HandleVariable(Dwarf_Debug dbg, Dwarf_Die die)
{
	Dwarf_Unsigned offset=0;
	Dwarf_Die   die_type;
	Dwarf_Die   die_parent = die;
	/*Dwarf_Error error = 0;*/
	Dwarf_Addr  Addr  = 0;
	/*int         res   = 0;*/
	unsigned int ident=0;

	char       buffer[1024];

	/* ---- Check if the current DIE is a variable -----*/
	if(DIE_IsVariable(dbg,die) != 0)
	{
		/* ---- Get the static address of the variables ----*/
		DIE_GetStaticAddress(dbg,die,&Addr);


		/*---- Do not consider optimised values ----*/
		if(Addr > 0u)
		{
			/* ---- Put the variable in the execution list ----*/
			die_list_Set(die_parent,0,(unsigned long)Addr);

			DIE_VAR_NAME_CNT = 0;

			/* ---- For each element from the variable do -----*/
			while(die_list_IsEmpty() == 0)
			{

				/* ---- Adapt the output buffer for the next variable ----*/
				memset(&DIE_VAR_NAME[die_list_last_Indent()],0,DIE_VAR_NAME_SIZE - die_list_last_Indent());
				DIE_VAR_NAME_CNT=die_list_last_Indent();

				/* ---- Consider the top of the task list ---*/
				die_parent = die_list_Get(&ident,(unsigned long*)&Addr);



				if(die_parent != NULL)
				{
					/* ---- If addr is bigger than 0 then there is a real address of the object ----*/
					if(Addr > 0)
					{
						/* ---- For each element with "member location attribute ----"*/
						DIE_GetMemberLocation(dbg,die_parent,&offset);
						printf("[%08X][%04X]:",(unsigned)Addr,(unsigned)offset);
					}

					/* ----- Get the name of the variable/member ----*/
					DIE_GetDIEName(dbg,die_parent,buffer);

					/* ---- Copy in the output buffer ----*/
					memcpy(&DIE_VAR_NAME[DIE_VAR_NAME_CNT],buffer,strlen(buffer));
					DIE_VAR_NAME_CNT += strlen(buffer);

					/* ---- Get the real type ---- */
					DIE_GetDieRealType(dbg,die_parent,&die_type,((unsigned long)Addr)+offset);
					/* ---- Print Variable -----*/
					puts(DIE_VAR_NAME);
				}/* End if*/

			}
		}/* End if Addr >0 */

	}

}
/**********************************************************
 * Description : This function returns one of the "real" types:
 * - DW_TAG_array_type
 * - DW_TAG_class_type
 * - DW_TAG_pointer_type
 * - DW_TAG_structure_type
 * - DW_TAG_union_type
 **********************************************************/
Dwarf_Half DIE_GetDieRealType(Dwarf_Debug dbg, Dwarf_Die die, Dwarf_Die *child,unsigned long address)
{
	Dwarf_Die die_parent;
	Dwarf_Die die_child;

	Dwarf_Unsigned  size =0;
	Dwarf_Error error = 0;
	Dwarf_Half  Tag   = 0;
	int         res   = 0;
	int         done  = 0;


	char       buffer[1024];

	die_parent = die;
	/* ---- Get the main Type ----*/
	while((res =DIE_Get_DIE_Type(dbg,die_parent,&die_child)) == DW_DLV_OK)
	{
		/* ----- Check the type of the ... type ----*/
		res = dwarf_tag(die_child,&Tag,&error);

		if(res == DW_DLV_OK)
		{
			/* ---- Check the TAG of DIE  ---- */
			switch(Tag)
			{
			case DW_TAG_base_type:
			{

				/* ---- Get member size -----*/
				DIE_GetMemberSize(dbg, die_child, &size);
				printf("[0x%04X]>",(unsigned int )size);


				/* ----- Get the name of the variable ----*/
				DIE_GetDIEBaseTypeName(dbg,die_child,buffer);
				/* ---- Copy in the output buffer ----*/
				DIE_VAR_NAME[DIE_VAR_NAME_CNT]='\t';
				DIE_VAR_NAME_CNT++;


				memcpy(&DIE_VAR_NAME[DIE_VAR_NAME_CNT],buffer,strlen(buffer));
				DIE_VAR_NAME_CNT += strlen(buffer);


				done =1;
				if(die_parent != die)
				{
					/* ---- Dealloc the die -----*/
					dwarf_dealloc(dbg,die_parent,DW_DLA_DIE);
				}
			} break;
			case DW_TAG_array_type:
			{

 				/* ---- Array info type -----*/
				sprintf(&DIE_VAR_NAME[DIE_VAR_NAME_CNT],"[%d]",DIE_Get_ArraySize(dbg,die_child));
				DIE_VAR_NAME_CNT += strlen(&DIE_VAR_NAME[DIE_VAR_NAME_CNT]);

				if(die_parent != die)
				{
					/* ---- Dealloc the die -----*/
					dwarf_dealloc(dbg,die_parent,DW_DLA_DIE);
				}
				/* ---- consider the next element ---*/
				die_parent = die_child;

			}break;
			case DW_TAG_class_type:
			case DW_TAG_structure_type:
			{
				/* ---- Get member size -----*/
				DIE_GetMemberSize(dbg, die_child, &size);
				printf("[0x%04X]>",(unsigned int)size);

				memcpy(&DIE_VAR_NAME[DIE_VAR_NAME_CNT],".",strlen("."));
				DIE_VAR_NAME_CNT += strlen(".");
				done =1;
				/* ---- add members to the queue ----*/
				DIE__AddMembers2Stack(dbg,die_child,address);

				if(die_parent != die)
				{
					/* ---- Dealloc the die -----*/
					dwarf_dealloc(dbg,die_parent,DW_DLA_DIE);
				}
			}break;
			case DW_TAG_union_type:
			{
				/* ---- Get member size -----*/
				DIE_GetMemberSize(dbg, die_child, &size);
				printf("[0x%04X]>",(unsigned int)size);

				memcpy(&DIE_VAR_NAME[DIE_VAR_NAME_CNT],".",strlen("."));
				DIE_VAR_NAME_CNT += strlen(".");
				done =1;
				/* ---- add members to the queue ----*/
				DIE__AddMembers2Stack(dbg,die_child,address);

				if(die_parent != die)
				{
					/* ---- Dealloc the die -----*/
					dwarf_dealloc(dbg,die_parent,DW_DLA_DIE);
				}
			}break;
			case DW_TAG_pointer_type:
			{

				/* ---- Get member size -----*/
				DIE_GetMemberSize(dbg, die_child, &size);
				printf("[0x%04X]>",(unsigned int)size);

				/* ---- Pointer info type -----*/
				memcpy(&DIE_VAR_NAME[DIE_VAR_NAME_CNT],"\t_PTR_",strlen("\t_PTR_"));
				DIE_VAR_NAME_CNT += strlen("\t_PTR_");

				done =1;
				if(die_parent != die)
				{
					/* ---- Dealloc the die -----*/
					dwarf_dealloc(dbg,die_parent,DW_DLA_DIE);
				}
				/* ---- consider the next element ---*/
				//die_parent = die_child;
			}break;
			case DW_TAG_enumeration_type:
			{
				/* ---- Get member size -----*/
				DIE_GetMemberSize(dbg, die_child, &size);
				printf("[0x%04X]>",(unsigned int)size);

				/* ---- Array info type -----*/
				memcpy(&DIE_VAR_NAME[DIE_VAR_NAME_CNT],"\t_ENUM_",strlen("\t_ENUM_"));
				DIE_VAR_NAME_CNT += strlen("\t_ENUM_");

				done =1;
				if(die_parent != die)
				{
					/* ---- Dealloc the die -----*/
					dwarf_dealloc(dbg,die_parent,DW_DLA_DIE);
				}
				/* ---- consider the next element ---*/
				//	die_parent = die_child;
			}break;
			case DW_TAG_subroutine_type:
			{
				/* ---- Get member size -----*/
				DIE_GetMemberSize(dbg, die_child, &size);
				printf("[0x%04X]>",(unsigned int)size);

				memcpy(&DIE_VAR_NAME[DIE_VAR_NAME_CNT],"\t_CALLBACK_",strlen("\t_CALLBACK_"));
				DIE_VAR_NAME_CNT += strlen("\t_CALLBACK_");

				done =1;
				if(die_parent != die)
				{
					/* ---- Dealloc the die -----*/
					dwarf_dealloc(dbg,die_parent,DW_DLA_DIE);
				}
				/* ---- consider the next element ---*/
				//	die_parent = die_child;
			}break;
			default:
			{
				if(die_parent != die)
				{
					/* ---- Dealloc the die -----*/
					dwarf_dealloc(dbg,die_parent,DW_DLA_DIE);
				}
				/* ---- consider the next element ---*/
				die_parent = die_child;
			}break;
			}
		}

		if(done == 1)
		{
			break;
		}
	}
	return (done == 1)? Tag: 0;
}
/**********************************************************
 * Description : return if the current die is a
 * global variable.
 **********************************************************/
int DIE_IsVariable(Dwarf_Debug dbg, Dwarf_Die die)
{
	int ret            = 0;
	int res            = 0;
	Dwarf_Error error  = 0;
	Dwarf_Half  tag    = 0;
	/* ----- Get the Type of the DIE ---- */
	res = dwarf_tag(die,&tag,&error);
	if(res == DW_DLV_OK)
	{
		/* ---- Check if the DIE is a variable ---- */
		if(DW_TAG_variable == tag)
		{
			ret = 1;
		}
	}

	return ret;
}




/**********************************************************************
 * Description: Get the DIE of the type of the variable using the offset
 * Return : DW_DLV_OK - Success
 **********************************************************************/
int  DIE_Get_DIE_Type(Dwarf_Debug dbg, Dwarf_Die die, Dwarf_Die *child)
{
	Dwarf_Attribute  Type; /* DW_AT_Type */
	Dwarf_Error      error = 0;
	Dwarf_Off        Offset;
	int res = 0;

	/* ---- Get the address of the variable ----*/
	res = dwarf_attr(die,DW_AT_type,&Type,&error);

	/* ---- Check if there is any kind of Location attribute ----*/
	if(res == DW_DLV_OK )
	{
		/* ---- Get the Offset of the type ---- */
		res = dwarf_global_formref(Type,&Offset,&error);

		if(res == DW_DLV_OK)
		{
			/* ---- Get the die using the offset ----*/
			res = dwarf_offdie(dbg,Offset,child,&error);
		}
	}
	if(res != DW_DLV_OK)
	{
		printf(" _VOID_ ");
	}

	return res;
}

/**********************************************************************
 * Description: Get the DIE array size
 * Return : DW_DLV_OK - Success
 **********************************************************************/
int  DIE_Get_ArraySize(Dwarf_Debug dbg, Dwarf_Die die)
{
	Dwarf_Attribute  Size;
	Dwarf_Error      error = 0;
	Dwarf_Signed     data  =-1;
	Dwarf_Die        next_die;
	int res  = 0;

	/* ---- Get the next siblings of the element ----*/
	res = dwarf_child(die,&next_die,&error);

	/* ---- Check for the errors  ----*/
	if(res == DW_DLV_OK )
	{
		/* ---- Get the address of the variable ----*/
		res = dwarf_attr(next_die,DW_AT_upper_bound,&Size,&error);

		/* ---- Check if there is any kind of array size attribute ----*/
		if(res == DW_DLV_OK )
		{
			/* ---- Get the Offset of the type ---- */
			res = dwarf_formsdata(Size,&data,&error);

			if(res == DW_DLV_OK)
			{
				/* ---- Increment one time since the function returs the max index  ----*/
				data+=1;
			}

		}


		/* ---- Dealloc the die -----*/
		dwarf_dealloc(dbg,next_die,DW_DLA_DIE);
	}


	return data;
}

void DIE__AddMembers2Stack(Dwarf_Debug dbg, Dwarf_Die die,unsigned long address)
{
	int res = 0;
	Dwarf_Half  tag    = 0;
	Dwarf_Half  flag    = 0;
	Dwarf_Die   child_die;
	Dwarf_Die   parent_die = die;
	Dwarf_Error error = 0;
	unsigned int ident =  DIE_VAR_NAME_CNT;

	do
	{
		dwarf_die_abbrev_children_flag(parent_die,&flag);
		if(flag != 0)
		{
			res = dwarf_child(parent_die,&child_die,&error);

		}
		else
		{
			/* ---- Read the next DIE  ---- */;
			res = dwarf_siblingof(dbg,parent_die,&child_die,&error);
		}

		if(res == DW_DLV_OK)
		{
			res = dwarf_tag(child_die,&tag,&error);

			if(DW_TAG_member == tag)
			{

				if(die_list_AddNext(child_die,ident,address) == 0)
				{
					break;
				}
			}
			parent_die = child_die;
		}
		if(res == DW_DLV_ERROR)
		{
			break;
		}

	}while(res != DW_DLV_NO_ENTRY);
}


void DIE_GetStaticAddress(Dwarf_Debug dbg, Dwarf_Die print_me, Dwarf_Addr *Addr)
{
	Dwarf_Attribute  Address;
	Dwarf_Error      error = 0;
	/* ---- location descriptors variable ----*/
	Dwarf_Signed lcnt;
	Dwarf_Locdesc **llbuf;
	int res   = 0;

	/* ---- Get the address of the variable ----*/
	res = dwarf_attr(print_me,DW_AT_location,&Address,&error);

	/* ---- Check if there is any kind of Location attibute ----*/
	if(res == DW_DLV_OK )
	{
		/* ---- Load Location list ---- */
		res = dwarf_loclist_n(Address, &llbuf,&lcnt, &error);

		if (res == DW_DLV_OK)
		{
			if((lcnt >=1)&&(llbuf[0]->ld_cents == 1))
			{
				*Addr = (llbuf[0]->ld_s[0]).lr_number;
			}
		}

	}
	else
	{
		//printf("[NO LOCATION]");
	}

}


void DIE_GetMemberLocation(Dwarf_Debug dbg, Dwarf_Die die, Dwarf_Unsigned *off)
{
	/* ---- Address value ---*/
	Dwarf_Unsigned       offset;
	Dwarf_Attribute  Attr;
	Dwarf_Error      error = 0;

	int res   = 0;

	/* ---- Get the member location of the variable ----*/
	res = dwarf_attr(die,DW_AT_data_member_location,&Attr,&error);

	/* ---- Check if there is any kind of Location attibute ----*/
	if(res == DW_DLV_OK )
	{
		res = dwarf_formudata(Attr, &offset, &error);

		if (res == DW_DLV_OK)
		{
			*off =offset;
		}

	}
	else
	{

	}

}
void DIE_GetMemberSize(Dwarf_Debug dbg, Dwarf_Die die, Dwarf_Unsigned *size)
{
	/* ---- Address value ---*/
	Dwarf_Unsigned   size_loc;
	Dwarf_Attribute  Attr;
	Dwarf_Error      error = 0;

	int res   = 0;

	/* ---- Get the member location of the variable ----*/
	res = dwarf_attr(die,DW_AT_byte_size,&Attr,&error);

	/* ---- Check if there is any kind of Location attibute ----*/
	if(res == DW_DLV_OK )
	{
		res = dwarf_formudata(Attr, &size_loc, &error);

		if (res == DW_DLV_OK)
		{
			*size =size_loc;
		}

	}
	else
	{

	}
}
