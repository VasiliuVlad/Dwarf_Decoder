#include <sys/types.h> /* For open() */
#include <sys/stat.h> /* For open() */
#include <fcntl.h> /* For open() */
#include <stdlib.h> /* For exit() */
#include <unistd.h> /* For close() */
#include <stdio.h>
#include <errno.h>
#include "dwarf.h"
#include "libdwarf.h"
#include "die_list.h"

/*******************************************
 * STATIC DATA
 *******************************************/
static die_tstNode *die_list = NULL;

/*******************************************
 * Description : function to push a die into
 * stack .
 *******************************************/
int die_list_AddNext(Dwarf_Die die,  unsigned int identation,unsigned long address)
{
	int ret = 0;
	die_tstNode *next_node = NULL;
	die_tstNode *aux_node = NULL;
	/* ---- Check if the list is empty ----*/
	if(die_list == NULL)
	{
		/* --- Allocate the first element ----- */
		die_list = malloc(sizeof(die_tstNode));

		/* ---- Check for the correct allocation ---- */
		if(die_list == NULL)
		{
			printf("ERROR: List cannot be allocated !! Memory full \n");
		}
		else
		{

			/* ---- Init the stack ----*/
			die_list->identation = identation;
			die_list->addr = address;
			die_list->die = die;
			die_list->next = NULL;
			ret = 1u;
		}
	}
	else
	{
		/* --- Allocate the next element ----- */
		next_node = malloc(sizeof(die_tstNode));

		/* ---- Check for the correct allocation ---- */
		if(next_node == NULL)
		{
			printf("ERROR: Stack node cannot be allocated !! Memory full \n");
		}
		else
		{
			aux_node  = die_list;

			while(aux_node->next != NULL)
			{
				aux_node  = aux_node->next;
			}


			/* ---- Init the stack node and update the stack pointer ----*/
			next_node->die        = die;
			next_node->next       = NULL;
			next_node->identation = identation;
			next_node->addr       = address;
			/* ---- add connection  ----*/
			aux_node->next = next_node;

			ret = 1u;
		}

	}
	return ret;
}

int die_list_Set(Dwarf_Die die, unsigned int identation,unsigned long address)
{
	int ret = 0;
	die_tstNode *next_node = NULL;
	/*die_tstNode *aux_node = NULL;*/
	/* ---- Check if the list is empty ----*/
	if(die_list == NULL)
	{
		/* --- Allocate the first element ----- */
		die_list = malloc(sizeof(die_tstNode));

		/* ---- Check for the correct allocation ---- */
		if(die_list == NULL)
		{
			printf("ERROR: List cannot be allocated !! Memory full \n");
		}
		else
		{
			/* ---- Init the stack ----*/
			die_list->identation = identation;
			die_list->addr       = address;
			die_list->die        = die;
			die_list->next       = NULL;
			ret = 1u;
		}
	}
	else
	{
		/* --- Allocate the next element ----- */
		next_node = malloc(sizeof(die_tstNode));

		/* ---- Check for the correct allocation ---- */
		if(next_node == NULL)
		{
			printf("ERROR: Stack node cannot be allocated !! Memory full \n");
		}
		else
		{
			/* ---- Init the stack node and update the stack pointer ----*/
			next_node->die        = die;
			next_node->next       = die_list;
			next_node->identation = identation;
			die_list->addr        = address;
			/* ---- Update the pointer list */
			die_list = next_node;

			ret = 1u;
		}

	}
	return ret;
}
Dwarf_Die  die_list_Get(unsigned int *ident,unsigned long *address)
{
	Dwarf_Die die;

	die_tstNode *aux_node = NULL;
	die_tstNode *prev_node = NULL;

	/* ---- Check if the list is empty ----*/
	if(die_list == NULL)
	{
		die = NULL;
	}
	else
	{
		aux_node  = die_list;
		prev_node = NULL;

		/* ---- Go to the last element of the list ----*/
		while(((aux_node->next)) != NULL)
		{
			prev_node = aux_node;
			aux_node  = aux_node->next;
		}
		/* ---- Get the data from the last element ----*/
		die      = aux_node->die;
		*ident   = aux_node->identation;
		*address = aux_node->addr;
		/* ---- Check if the list is bigger than 1 ----*/
		if(prev_node  != NULL)
		{
			/* ---- Disconnect the last element -----*/
			prev_node->next = NULL;
			/* ---- unalocate the last element ----*/
			free(aux_node);
		}
		else
		{
			/*---- Mark the empty list ----*/
			die_list = NULL;
			/* ---- unalocate the element ----*/
			free(aux_node);
		}

	}

	return die;
}
unsigned int  die_list_last_Indent()
{
	unsigned int ident =0;
	die_tstNode *aux_node = NULL;

	/* ---- Check if the stack is empty ----*/
	if(die_list == NULL)
	{
		ident =0;
	}
	else
	{
		aux_node  = die_list;

		/* ---- Go to the last element of the list ----*/
		while(((aux_node->next)) != NULL)
		{
			aux_node  = aux_node->next;
		}

		/* ---- Get the pointer -----*/
		ident = aux_node->identation;

	}

	return ident;
}

Dwarf_Die  die_list_next()
{
	Dwarf_Die   die;
	die_tstNode *aux_node = NULL;

	/* ---- Check if the stack is empty ----*/
	if(die_list == NULL)
	{
		die = NULL;
	}
	else
	{
		aux_node  = die_list;

		/* ---- Go to the last element of the list ----*/
		while(((aux_node->next)) != NULL)
		{
			aux_node  = aux_node->next;
		}

		/* ---- Get the pointer -----*/
		die = aux_node->die;

	}

	return die;
}
int die_list_IsEmpty()
{
	int ret = 0;

	if(die_list == NULL)
	{
		ret =1;
	}

	return ret;
}

