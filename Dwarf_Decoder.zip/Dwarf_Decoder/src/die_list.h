
#ifndef _DIE_LIST_
#define _DIE_LIST_

typedef struct die_stnode
	{
	unsigned int       identation;
	unsigned long int  addr;
	Dwarf_Die          die;
	struct die_stnode *next;
	} die_tstNode;


int die_list_Set(Dwarf_Die die, unsigned int identation,unsigned long address);
int die_list_AddNext(Dwarf_Die die,  unsigned int identation,unsigned long address);
Dwarf_Die  die_list_Get(unsigned int *ident, unsigned long *address);
Dwarf_Die  die_list_next();
int die_list_IsEmpty();
unsigned int  die_list_last_Indent();

#endif

/* ----- End of file ----*/

