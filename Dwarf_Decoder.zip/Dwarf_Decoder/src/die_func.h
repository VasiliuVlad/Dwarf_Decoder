/*
 * die_func.h
 *
 *  Created on: Feb 1, 2015
 *      Author: vlad
 */

#ifndef DIE_FUNC_H_
#define DIE_FUNC_H_



void DIE_HandleVariable(Dwarf_Debug dbg, Dwarf_Die die);

#endif /* DIE_FUNC_H_ */
